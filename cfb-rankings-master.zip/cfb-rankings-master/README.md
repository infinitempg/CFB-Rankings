# College Football Rankings - The Right Way

Explained in detail at [http://www.devinyoungweb.com/blog/cfb-rankings-the-right-way](http://www.devinyoungweb.com/blog/cfb-rankings-the-right-way)
